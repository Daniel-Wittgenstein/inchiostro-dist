
# Inchiostro Story Template

A story template for Ink. Dev.
